<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';

function auth_login_user(array $user): void {
    $_SESSION['user_id'] = intval($user['id']);
    $_SESSION['user_role'] = (string)($user['role'] ?? 'cashier');
    $_SESSION['username'] = (string)($user['username'] ?? '');
}

function auth_logout_user(): void {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'], $params['secure'], $params['httponly']
        );
    }

    session_destroy();
}

function auth_current_user(): ?array {
    $userId = intval($_SESSION['user_id'] ?? 0);
    if ($userId <= 0) {
        return null;
    }

    try {
        $db = Database::getInstance();
        $user = $db->query('SELECT id, username, role FROM users WHERE id = ?', [$userId]);

        if (!$user) {
            return null;
        }

        $_SESSION['user_role'] = (string)($user['role'] ?? 'cashier');
        $_SESSION['username'] = (string)($user['username'] ?? '');

        return $user;
    } catch (Throwable $error) {
        return null;
    }
}

function auth_redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

function auth_require_login(string $loginPath = 'vendedor_login.php'): array {
    $user = auth_current_user();
    if (!$user) {
        auth_logout_user();
        auth_redirect($loginPath);
    }
    return $user;
}

function auth_require_role(array $roles, string $loginPath = 'vendedor_login.php', string $forbiddenPath = 'index.php'): array {
    $user = auth_require_login($loginPath);
    $role = (string)($user['role'] ?? '');

    if (!in_array($role, $roles, true)) {
        auth_redirect($forbiddenPath);
    }

    return $user;
}

function auth_require_api_role(array $roles): array {
    header('Content-Type: application/json');

    $user = auth_current_user();
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'Autenticación requerida.']);
        exit;
    }

    $role = (string)($user['role'] ?? '');
    if (!in_array($role, $roles, true)) {
        echo json_encode(['success' => false, 'message' => 'No tienes permisos para esta acción.']);
        exit;
    }

    return $user;
}
