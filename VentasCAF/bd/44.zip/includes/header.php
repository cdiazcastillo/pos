<?php
require_once __DIR__ . '/auth.php';
$currentUser = auth_require_login('vendedor_login.php');

$db = Database::getInstance();
$active_shift = $db->query("SELECT id FROM shifts WHERE user_id = ? AND status = 'open'", [$_SESSION['user_id']]);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? '4 Básico A'; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="img/logo.png" alt="Logo" style="max-width: 100px;">
            <h1><?php echo $page_title ?? '4 Básico A'; ?></h1>
            <div>
                <a href="admin.php" class="btn btn-secondary">Menú Principal</a>
            </div>
        </div>
        <div class="content">